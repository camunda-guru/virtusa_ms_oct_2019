package com.virtusa.kafkaproducer.models;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Beneficiary{
	 
	private String firstName;
	private String lastName;
	private long accountNo;

	
}
