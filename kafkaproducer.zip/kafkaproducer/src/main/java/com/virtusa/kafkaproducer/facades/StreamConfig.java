package com.virtusa.kafkaproducer.facades;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(BeneficiaryStreams.class)
public class StreamConfig {
}
