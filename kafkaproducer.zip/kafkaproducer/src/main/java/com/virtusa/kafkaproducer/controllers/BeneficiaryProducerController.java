package com.virtusa.kafkaproducer.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.kafkaproducer.models.Beneficiary;
import com.virtusa.kafkaproducer.services.BeneficiaryService;

@RestController
public class BeneficiaryProducerController {
	@Autowired
	private BeneficiaryService beneficiaryService;
   
    @PostMapping("/addBeneficiary")
    public @ResponseBody String publishBeneficiary(@RequestBody Beneficiary beneficiary) {
       
    	boolean status = beneficiaryService.addBeneficiaryInfo(beneficiary);
    	if(status)
    		return "Added Beneficiary";
    	else
    		return "Not Added";
    }
}
