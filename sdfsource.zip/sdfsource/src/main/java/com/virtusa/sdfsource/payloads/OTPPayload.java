package com.virtusa.sdfsource.payloads;

import java.util.Date;
import java.util.Random;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.support.MessageBuilder;

import com.virtusa.sdfsource.models.OTP;

@EnableBinding(Source.class)
public class OTPPayload {
	private OTP otp;
	@Bean
	@InboundChannelAdapter(value = Source.OUTPUT, 
	poller = @Poller(fixedDelay = "10000", maxMessagesPerPoll = "1"))
	public MessageSource<Integer> otpMessageSource() {
		otp=new OTP();		
		otp.setOtpValue(new Random().nextInt(100000));
		return () -> MessageBuilder.withPayload(otp.getOtpValue()).build();
	}


}
