package com.virtusa.sdfsource.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OTP {
	private int otpValue;

}
