package com.virtusa.sdfsource.payloads;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.support.MessageBuilder;

import com.virtusa.sdfsource.models.OTP;

@EnableBinding(Processor.class)
public class OTPPayload {
	private OTP otp;
	@Transformer(inputChannel = Processor.INPUT, outputChannel = Processor.OUTPUT)
    public Integer transform(Integer otpNumber) {
       // OTP otp=new OTP();
        //otp.setOtpValue(otpNumber*1000000000%7);
		return otpNumber*1000000000%7;
    }



}
