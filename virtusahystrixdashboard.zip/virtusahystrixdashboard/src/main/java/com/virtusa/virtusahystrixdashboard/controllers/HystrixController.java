package com.virtusa.virtusahystrixdashboard.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.virtusahystrixdashboard.models.Beneficiary;
import com.virtusa.virtusahystrixdashboard.services.HystrixService;

@RestController
public class HystrixController {
	@Autowired
	private HystrixService hystrixService;
	@PostMapping("/add")
	public String addBeneficiary(@RequestBody Beneficiary beneficiary)
	{
		return hystrixService.handleRequest(beneficiary);
		
	}

}
