package com.virtusa.virtusahystrixdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtusahystrixdashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
