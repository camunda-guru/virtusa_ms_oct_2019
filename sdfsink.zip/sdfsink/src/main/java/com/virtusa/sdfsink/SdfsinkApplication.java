package com.virtusa.sdfsink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdfsinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SdfsinkApplication.class, args);
	}

}
