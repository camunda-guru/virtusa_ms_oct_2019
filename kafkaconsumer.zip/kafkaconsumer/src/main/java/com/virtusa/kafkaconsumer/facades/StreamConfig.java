package com.virtusa.kafkaconsumer.facades;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(BeneficiaryStreams.class)
public class StreamConfig {
}
