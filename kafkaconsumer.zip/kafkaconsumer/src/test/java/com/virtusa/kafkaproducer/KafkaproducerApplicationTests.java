package com.virtusa.kafkaproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
