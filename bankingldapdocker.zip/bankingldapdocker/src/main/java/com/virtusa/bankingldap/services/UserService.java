package com.virtusa.bankingldap.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.bankingldap.models.User;
import com.virtusa.bankingldap.repositories.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
	public User getUserByName(String userName)
	{
		return userRepository.findById(userName).orElse(null);
	}
	

}
