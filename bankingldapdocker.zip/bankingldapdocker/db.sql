# Create virtusa db database if it doesn't exist
CREATE DATABASE IF NOT EXISTS virtusacustomerdb;
# Grant all privilidges on second_db to org_user
#GRANT ALL PRIVILEGES ON second_db.* TO 'org_user' identified by 'org_user_password';