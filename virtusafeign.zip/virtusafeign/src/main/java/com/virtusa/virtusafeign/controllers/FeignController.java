package com.virtusa.virtusafeign.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.virtusafeign.models.User;

@RestController
public class FeignController {
    @Autowired
	private UserProxy userProxy;
	
	@GetMapping("/feignuser/{userName}")
	public User getAllUsers(@PathVariable("userName") String userName)
	{
		return userProxy.findByName(userName);
		
	}
	
}
