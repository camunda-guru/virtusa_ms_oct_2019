package com.virtusa.virtusafeign.controllers;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.virtusa.virtusafeign.models.User;

@FeignClient(name="LDAP-APP" )//Service Id of User service
public interface UserProxy {

	 @RequestMapping("/getuser/{userName}")
	 public User findByName(@PathVariable(value="userName") String userName);
	
}
