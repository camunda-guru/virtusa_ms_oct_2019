package com.virtusa.virtusafeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtusafeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
