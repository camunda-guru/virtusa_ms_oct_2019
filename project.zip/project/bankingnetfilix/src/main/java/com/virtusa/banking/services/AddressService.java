package com.virtusa.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.models.Address;
import com.virtusa.banking.models.Customer;
import com.virtusa.banking.repositories.AddressRepository;


@Service
public class AddressService {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private AddressRepository addressRepository;
	
	//insert
	public Address addAddress(Address address, Long customerId)
	{
		//find the customer
		Customer customer=customerService.getCustomerById(customerId);
		address.setCustomer(customer);
		return addressRepository.save(address);
		
	}
	//select all
		public List<Address> getAllAddresses()
		{
			return addressRepository.findAll();
		}
		
		//select one
		public Address getAddressById(long id)
		{
			return addressRepository.findById(id).orElse(null);
		}
		//update 
		public Address updateAddress(Address address)
		{
			return addressRepository.save(address);
		}
		//delete
		public void deleteAddress(long id)
		{
			addressRepository.deleteById(id);
		}

}
