package com.virtusa.bankingapigateway.configurations;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.virtusa.bankingapigateway.models.User;
import com.virtusa.bankingapigateway.models.UserRole;



@Service("userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {

	 @Autowired
     protected RestTemplate restTemplate;
	//@Transactional(readOnly = true)

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("UserName received as=" + username);
		User user=restTemplate.getForObject("http://localhost:6070/getuser/admin",User.class);
		if(user==null)
			System.out.println("User not found");
		System.out.println("Found=" + user.getUserName() + "," + user.getPassword() + "," + user.isEnabled());

		UserBuilder builder = null;
		if (user != null) {

			builder = org.springframework.security.core.userdetails.User.withUsername(username);

			if (user.isEnabled()) {
				builder.disabled(false);
			}
			builder.password(user.getPassword());
			
			String[] authorities=restTemplate.getForObject("http://localhost:6070/getuserroles/"+username,String[].class);
					
			System.out.println("Length=" + authorities.length);
			builder.authorities(authorities);
		} else {
			throw new UsernameNotFoundException("User not found.");
		}
		return builder.build();

	}

}
