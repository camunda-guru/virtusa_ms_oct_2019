package com.virtusa.accounts.services;


import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.security.crypto.codec.Base64;
import com.virtusa.accounts.models.Account;
import com.virtusa.accounts.models.Customer;
import com.virtusa.accounts.repositories.AccountRepository;

@Service
public class AccountService {
    @Autowired
	private AccountRepository accountRepository;
    @Autowired
	protected RestTemplate restTemplate;
    private static HttpHeaders getHeaders(){
        String plainCredentials="admin:admin@123";
        String base64Credentials = new String(Base64.encode(plainCredentials.getBytes()));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Basic " + base64Credentials);
        headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return headers;
    }
     
    
    //insert
    public Account addAccount(Account account,String serviceUrl)
    {
    	//business interservice communication
    	
    	 HttpEntity<String> request = new HttpEntity<String>(getHeaders());
    	 ResponseEntity<Customer> customerResponse =restTemplate.exchange(serviceUrl+"/getcustomerbyid/"+account.getCustomerId(),HttpMethod.GET,request,Customer.class);
    	Customer customer=customerResponse.getBody();
    	 if (customer!=null)
    	   return accountRepository.insert(account);
    	else
    		return null;
    }
    
    public List<Account> getAllAccounts()
    {
    	return accountRepository.findAll();
    }
    
    public Account getAccountById(long accountNo)
    {
    	return accountRepository.findByAccountNo(accountNo);
    }
    
    
    public void deleteAccountById(long accountNo)
    {
    	accountRepository.deleteByAccountNo(accountNo);
    }
    
	
}
