package com.virtusa.accounts.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.virtusa.accounts.models.Account;

public interface AccountRepository extends MongoRepository<Account,Long>{

	@Query("{ 'accountNo' : ?0 }")
    Account findByAccountNo(long accountNo);
	
	@Query(value="{accountNo : $0}", delete = true)
	Account deleteByAccountNo(long accountNo);
 
}
