package com.virtusa.accounts.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.accounts.models.Account;
import com.virtusa.accounts.services.AccountService;

@RefreshScope
@RestController
public class AccountController {
	@Autowired
	private AccountService accountService;
	@Value("${serviceUrl}")
    private String serviceUrl;
	
	@CrossOrigin("*")
	@PostMapping("/saveaccount")
	public @ResponseBody ResponseEntity<?> saveAccount(@RequestBody Account account)
	{
		Account accountResponse=accountService.addAccount(account,serviceUrl);
		if(accountResponse!=null)
		{
			return ResponseEntity.ok(accountResponse);
		}
		else
			return ResponseEntity.ok("Customer Not existing");
	}
	@CrossOrigin("*")
	@GetMapping("/getaccounts")
	public List<Account> findAllAccounts()
	{
		return accountService.getAllAccounts();
	}
	
	@CrossOrigin("*")
	@GetMapping("/getaccountbyid/{accountNo}")
	public Account findAccountById(@PathVariable("accountNo") long accountNo)
	{
		return accountService.getAccountById(accountNo);
	}
}
