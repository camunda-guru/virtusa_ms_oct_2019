package com.virtusa.bankingldap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingldapApplicationTests {

	@Test
	void contextLoads() {
	}

}
