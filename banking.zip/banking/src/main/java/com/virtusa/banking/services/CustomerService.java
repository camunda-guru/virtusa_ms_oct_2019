package com.virtusa.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.models.Customer;
import com.virtusa.banking.repositories.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepository;
	
	//insert 
	public Customer addCustomer(Customer customer)
	{
		return customerRepository.save(customer);
	}
	//select all
	public List<Customer> getAllCustomers()
	{
		return customerRepository.findAll();
	}
	
	//select one
	public Customer getCustomerById(long id)
	{
		return customerRepository.findById(id).orElse(null);
	}
	//update 
	public Customer updateCustomer(Customer customer)
	{
		return customerRepository.save(customer);
	}
	//delete
	public void deleteCustomer(long id)
	{
	     customerRepository.deleteById(id);
	}
	

}
