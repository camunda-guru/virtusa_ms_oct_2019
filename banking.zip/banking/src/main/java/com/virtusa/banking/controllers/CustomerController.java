package com.virtusa.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.models.Customer;
import com.virtusa.banking.services.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@CrossOrigin("*")
	@PostMapping("/savecustomer")
	public @ResponseBody Customer saveCustomer(@RequestBody Customer customer)
	{
		return customerService.addCustomer(customer);
	}
	@CrossOrigin("*")
	@GetMapping("/getcustomers")
	public List<Customer> findAllCustomers()
	{
		return customerService.getAllCustomers();
	}
	
	@CrossOrigin("*")
	@GetMapping("/getcustomerbyid/{id}")
	public Customer findCustomerById(@PathVariable("id") long id)
	{
		return customerService.getCustomerById(id);
	}
	
	@CrossOrigin("*")
	@DeleteMapping("/deletecustomerbyid/{id}")
	public boolean deleteCustomerById(@PathVariable("id") long id)
	{
		customerService.deleteCustomer(id);
		boolean status=false;
		if(customerService.getCustomerById(id)==null)
			status=true;
		return status;
	}
	
	
	@CrossOrigin("*")
	@PutMapping("/updatecustomer")
	public Customer updateCustomer(Customer customer)
	{
		return customerService.updateCustomer(customer);
	}
	
	
	
	
}
