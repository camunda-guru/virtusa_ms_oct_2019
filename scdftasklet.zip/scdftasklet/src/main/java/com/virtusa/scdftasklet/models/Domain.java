package com.virtusa.scdftasklet.models;
import lombok.Data;

@Data
public class Domain {
 
  int id;
  String domain;
}