package com.virtusa.scdftasklet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@ComponentScan(basePackages = {"com.virtusa.*"})
public class ScdftaskletApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScdftaskletApplication.class, args);
	}

}
